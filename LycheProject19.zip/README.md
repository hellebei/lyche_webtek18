# lyche_webtek18
Creating a webpage for lyche resturant in Trondheim
